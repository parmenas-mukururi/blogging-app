export const commentSchema = {
    comment: {
      notEmpty: {
        errorMessage: "Comment cannot be empty",
      },
    }
  };
