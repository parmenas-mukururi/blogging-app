import {PrismaClient} from "@prisma/client"
import { matchedData, validationResult } from "express-validator"
import jwt from "jsonwebtoken"
const prisma = new PrismaClient()


const createPost = async (req, res) => {
    console.log(req.body)
    try {
        const errors =  validationResult(req);
        if(!errors.isEmpty()) {
            return res.status(400).send({ status: 'fail', errors}).end()
        }
        const data = matchedData(req);

        const newPost = await prisma.posts.create({
            data: data
            //  {
            //     title: req.body.title,
            //     content: req.body.content,
            //     category : req.body.category
            // }
        })
        console.log(newPost)
        res.status(201).json(newPost)
    } catch (error) {
       console.log(error)
       res.status(500).send('Error creating post') 
    }
}

const getAllPosts = async (req, res) => {
    try {
        const posts = await prisma.posts.findMany()
        res.status(200).json(posts)
    } catch (error) {
        res.status(500).send('Error fetching posts')
    }
}

const getSinglePost = async (req, res) => {
    try {
        const post = await prisma.posts.findUnique({
            where: {
                id: req.params.id
            }
        })
        res.status(200).json(post)
    } catch (error) {
        
        res.status(500).send('Error fetching post')
    }
}

const updatePost = async () => {}
const deletePost = async () => {}

export { createPost, getAllPosts, getSinglePost}