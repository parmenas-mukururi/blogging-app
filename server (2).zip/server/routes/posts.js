import { Router } from "express";
import { createPost, getAllPosts, getSinglePost } from "../controllers/posts.js";
import { checkSchema } from "express-validator";
import { postSchema } from "../validators/postSchema.js";
import { requiredAuth } from "../middlewares/authUser.js";


const postRouter = Router()

postRouter.post("/posts", requiredAuth, checkSchema(postSchema), createPost)
postRouter.get("/posts", getAllPosts)
postRouter.get("/post/:id", getSinglePost)

export default postRouter