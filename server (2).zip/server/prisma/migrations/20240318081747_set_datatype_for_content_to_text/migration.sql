-- AlterTable
ALTER TABLE `posts` MODIFY `title` TEXT NOT NULL,
    MODIFY `content` TEXT NOT NULL;
