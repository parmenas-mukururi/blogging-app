-- AlterTable
ALTER TABLE `posts` MODIFY `updatedAt` DATETIME(3) NULL;
